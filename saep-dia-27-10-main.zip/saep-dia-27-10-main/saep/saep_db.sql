-- SAEP - Sistema de Assistência Técnica de Equipamentos de Informática
-- Script de criação e população do banco de dados

CREATE DATABASE IF NOT EXISTS saep_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE saep_db;

DROP TABLE IF EXISTS ordens_servico;
DROP TABLE IF EXISTS equipamentos;
DROP TABLE IF EXISTS clientes;
DROP TABLE IF EXISTS usuarios;

-- Tabela de usuários (autenticação)
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    perfil VARCHAR(30) NOT NULL DEFAULT 'Técnico'
) ENGINE=InnoDB;

-- Tabela de clientes
CREATE TABLE clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(120) NOT NULL,
    cpf VARCHAR(14) NOT NULL UNIQUE,
    telefone VARCHAR(20) NOT NULL,
    email VARCHAR(120),
    endereco VARCHAR(200),
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabela de equipamentos (associado a um cliente)
CREATE TABLE equipamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT NOT NULL,
    tipo VARCHAR(50) NOT NULL,
    marca VARCHAR(60) NOT NULL,
    modelo VARCHAR(80) NOT NULL,
    numero_serie VARCHAR(80),
    descricao TEXT,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_equipamento_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id)
) ENGINE=InnoDB;

-- Tabela de ordens de serviço
CREATE TABLE ordens_servico (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT NOT NULL,
    equipamento_id INT NOT NULL,
    usuario_id INT NOT NULL,
    descricao_problema TEXT NOT NULL,
    status ENUM('Aberta','Em andamento','Concluída','Cancelada') NOT NULL DEFAULT 'Aberta',
    data_abertura DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    data_conclusao DATETIME NULL,
    observacoes TEXT,
    CONSTRAINT fk_os_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id),
    CONSTRAINT fk_os_equipamento FOREIGN KEY (equipamento_id) REFERENCES equipamentos(id),
    CONSTRAINT fk_os_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
) ENGINE=InnoDB;

-- População: usuários (senha protegida com password_hash - senha de teste: 123456)
INSERT INTO usuarios (nome, email, senha, perfil) VALUES
('Administrador', 'admin@saep.local', '$2y$10$NK8ydilgUnt1sfoJccbotO7nq440u7E6ipJt9gFQ4NQ1mQWPUgDFC', 'Administrador'),
('Marina Silva', 'marina@saep.local', '$2y$10$NK8ydilgUnt1sfoJccbotO7nq440u7E6ipJt9gFQ4NQ1mQWPUgDFC', 'Técnico'),
('Carlos Souza', 'carlos@saep.local', '$2y$10$NK8ydilgUnt1sfoJccbotO7nq440u7E6ipJt9gFQ4NQ1mQWPUgDFC', 'Técnico');

-- Clientes (mínimo 3)
INSERT INTO clientes (nome, cpf, telefone, email, endereco) VALUES
('João Pedro Oliveira', '123.456.789-00', '(11) 98765-4321', 'joao.pedro@email.com', 'Rua das Flores, 100 - São Paulo/SP'),
('Ana Carolina Mendes', '987.654.321-00', '(21) 99876-5432', 'ana.mendes@email.com', 'Av. Atlântica, 500 - Rio de Janeiro/RJ'),
('Roberto Almeida Costa', '456.789.123-00', '(31) 97654-3210', 'roberto.costa@email.com', 'Rua da Bahia, 250 - Belo Horizonte/MG');

-- Equipamentos (mínimo 3, associados a clientes)
INSERT INTO equipamentos (cliente_id, tipo, marca, modelo, numero_serie, descricao) VALUES
(1, 'Notebook', 'Dell', 'Inspiron 15 3000', 'DL-INS-001234', 'Notebook com defeito na tela'),
(1, 'Impressora', 'HP', 'LaserJet Pro M404', 'HP-LJ-98765', 'Impressora a laser'),
(2, 'Desktop', 'Lenovo', 'ThinkCentre M720', 'LN-TC-55432', 'Computador de mesa'),
(3, 'Notebook', 'Acer', 'Aspire 5', 'AC-ASP-77889', 'Notebook para uso corporativo');

-- Ordens de serviço (mínimo 3)
INSERT INTO ordens_servico (cliente_id, equipamento_id, usuario_id, descricao_problema, status, data_abertura, observacoes) VALUES
(1, 1, 1, 'Tela com manchas e falhas de imagem após queda.', 'Aberta', '2026-10-20 09:30:00', 'Aguardando orçamento de peça'),
(2, 3, 2, 'Computador não liga. Possível problema na fonte.', 'Em andamento', '2026-10-22 14:15:00', 'Fonte testada, aguardando confirmação'),
(3, 4, 3, 'Sistema operacional lento e travamentos frequentes.', 'Concluída', '2026-10-18 11:00:00', 'Formatação e reinstalação realizadas'),
(1, 2, 2, 'Impressora não reconhece cartucho de toner.', 'Aberta', '2026-10-25 08:45:00', NULL);
