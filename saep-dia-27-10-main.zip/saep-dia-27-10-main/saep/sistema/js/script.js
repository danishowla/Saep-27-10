function confirmarExclusao() { return confirm('Deseja realmente excluir este chamado?'); }
