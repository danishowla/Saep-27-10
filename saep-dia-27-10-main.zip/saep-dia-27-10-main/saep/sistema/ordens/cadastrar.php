<?php
require_once "../config/auth.php";
verificarSessao();
require_once "../config/conexao.php";

$clientes = $conn->query("SELECT id, nome FROM clientes ORDER BY nome");
$equipamentos = $conn->query("
    SELECT e.id, e.tipo, e.marca, e.modelo, e.cliente_id, c.nome AS cliente_nome
    FROM equipamentos e
    INNER JOIN clientes c ON c.id = e.cliente_id
    ORDER BY c.nome, e.tipo
");
$erro = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $cliente_id = intval($_POST["cliente_id"] ?? 0);
    $equipamento_id = intval($_POST["equipamento_id"] ?? 0);
    $descricao = trim($_POST["descricao_problema"] ?? "");
    $status = $_POST["status"] ?? "Aberta";
    $observacoes = trim($_POST["observacoes"] ?? "");
    $usuario_id = $_SESSION["usuario_id"];

    if ($cliente_id <= 0 || $equipamento_id <= 0 || $descricao === "") {
        $erro = "Cliente, equipamento e descrição do problema são obrigatórios.";
    } else {
        $stmt = $conn->prepare("INSERT INTO ordens_servico (cliente_id, equipamento_id, usuario_id, descricao_problema, status, observacoes) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iiisss", $cliente_id, $equipamento_id, $usuario_id, $descricao, $status, $observacoes);
        if ($stmt->execute()) {
            header("Location: listar.php");
            exit;
        }
        $erro = "Erro ao cadastrar ordem de serviço.";
    }
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <title>Nova OS - SAEP</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header class="topbar">
        <strong>SAEP Assistência Técnica</strong>
        <div><?= htmlspecialchars($_SESSION["usuario_nome"]) ?> | <a href="../logout.php">Sair</a></div>
    </header>
    <main class="container form-container">
        <h1>Nova Ordem de Serviço</h1>
        <?php if ($erro): ?><div class="alert error"><?= htmlspecialchars($erro) ?></div><?php endif; ?>
        <form method="post">
            <label>Cliente *</label>
            <select name="cliente_id" id="cliente_id" required>
                <option value="">Selecione o cliente</option>
                <?php while ($c = $clientes->fetch_assoc()): ?>
                    <option value="<?= $c["id"] ?>"><?= htmlspecialchars($c["nome"]) ?></option>
                <?php endwhile; ?>
            </select>
            <label>Equipamento *</label>
            <select name="equipamento_id" id="equipamento_id" required>
                <option value="">Selecione o equipamento</option>
                <?php
                $equipamentos->data_seek(0);
                while ($e = $equipamentos->fetch_assoc()):
                ?>
                    <option value="<?= $e["id"] ?>" data-cliente="<?= $e["cliente_id"] ?>">
                        <?= htmlspecialchars($e["cliente_nome"] . " - " . $e["tipo"] . " " . $e["marca"] . " " . $e["modelo"]) ?>
                    </option>
                <?php endwhile; ?>
            </select>
            <label>Descrição do Problema *</label>
            <textarea name="descricao_problema" rows="4" required><?= htmlspecialchars($_POST["descricao_problema"] ?? "") ?></textarea>
            <label>Status</label>
            <select name="status">
                <option value="Aberta" selected>Aberta</option>
                <option value="Em andamento">Em andamento</option>
                <option value="Concluída">Concluída</option>
                <option value="Cancelada">Cancelada</option>
            </select>
            <label>Observações</label>
            <textarea name="observacoes" rows="2"><?= htmlspecialchars($_POST["observacoes"] ?? "") ?></textarea>
            <button type="submit">Salvar</button>
            <a class="button secondary" href="listar.php">Cancelar</a>
        </form>
    </main>
</body>
</html>
