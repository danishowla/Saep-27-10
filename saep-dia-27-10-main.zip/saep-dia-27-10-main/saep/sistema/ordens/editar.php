<?php
require_once "../config/auth.php";
verificarSessao();
require_once "../config/conexao.php";

$id = intval($_GET["id"] ?? 0);
$stmt = $conn->prepare("SELECT * FROM ordens_servico WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$os = $stmt->get_result()->fetch_assoc();

if (!$os) {
    die("Ordem de serviço não encontrada.");
}

$clientes = $conn->query("SELECT id, nome FROM clientes ORDER BY nome");
$equipamentos = $conn->query("
    SELECT e.id, e.tipo, e.marca, e.modelo, e.cliente_id, c.nome AS cliente_nome
    FROM equipamentos e
    INNER JOIN clientes c ON c.id = e.cliente_id
    ORDER BY c.nome, e.tipo
");
$erro = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $cliente_id = intval($_POST["cliente_id"] ?? 0);
    $equipamento_id = intval($_POST["equipamento_id"] ?? 0);
    $descricao = trim($_POST["descricao_problema"] ?? "");
    $status = $_POST["status"] ?? "Aberta";
    $observacoes = trim($_POST["observacoes"] ?? "");
    $data_conclusao = null;
    if ($status === "Concluída") {
        $data_conclusao = date("Y-m-d H:i:s");
    }

    if ($cliente_id <= 0 || $equipamento_id <= 0 || $descricao === "") {
        $erro = "Cliente, equipamento e descrição do problema são obrigatórios.";
    } else {
        $stmt = $conn->prepare("UPDATE ordens_servico SET cliente_id=?, equipamento_id=?, descricao_problema=?, status=?, observacoes=?, data_conclusao=? WHERE id=?");
        $stmt->bind_param("iissssi", $cliente_id, $equipamento_id, $descricao, $status, $observacoes, $data_conclusao, $id);
        if ($stmt->execute()) {
            header("Location: listar.php");
            exit;
        }
        $erro = "Erro ao atualizar ordem de serviço.";
    }
} else {
    $_POST = $os;
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <title>Editar OS - SAEP</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header class="topbar">
        <strong>SAEP Assistência Técnica</strong>
        <div><?= htmlspecialchars($_SESSION["usuario_nome"]) ?> | <a href="../logout.php">Sair</a></div>
    </header>
    <main class="container form-container">
        <h1>Editar Ordem de Serviço #<?= $id ?></h1>
        <?php if ($erro): ?><div class="alert error"><?= htmlspecialchars($erro) ?></div><?php endif; ?>
        <form method="post">
            <label>Cliente *</label>
            <select name="cliente_id" required>
                <?php while ($c = $clientes->fetch_assoc()): ?>
                    <option value="<?= $c["id"] ?>" <?= (($_POST["cliente_id"] ?? $os["cliente_id"]) == $c["id"]) ? "selected" : "" ?>>
                        <?= htmlspecialchars($c["nome"]) ?>
                    </option>
                <?php endwhile; ?>
            </select>
            <label>Equipamento *</label>
            <select name="equipamento_id" required>
                <?php while ($e = $equipamentos->fetch_assoc()): ?>
                    <option value="<?= $e["id"] ?>" <?= (($_POST["equipamento_id"] ?? $os["equipamento_id"]) == $e["id"]) ? "selected" : "" ?>>
                        <?= htmlspecialchars($e["cliente_nome"] . " - " . $e["tipo"] . " " . $e["marca"] . " " . $e["modelo"]) ?>
                    </option>
                <?php endwhile; ?>
            </select>
            <label>Descrição do Problema *</label>
            <textarea name="descricao_problema" rows="4" required><?= htmlspecialchars($_POST["descricao_problema"] ?? "") ?></textarea>
            <label>Status</label>
            <select name="status">
                <?php foreach (["Aberta", "Em andamento", "Concluída", "Cancelada"] as $s): ?>
                    <option value="<?= $s ?>" <?= (($_POST["status"] ?? $os["status"]) === $s) ? "selected" : "" ?>><?= $s ?></option>
                <?php endforeach; ?>
            </select>
            <label>Observações</label>
            <textarea name="observacoes" rows="2"><?= htmlspecialchars($_POST["observacoes"] ?? "") ?></textarea>
            <button type="submit">Salvar</button>
            <a class="button secondary" href="listar.php">Cancelar</a>
        </form>
    </main>
</body>
</html>
