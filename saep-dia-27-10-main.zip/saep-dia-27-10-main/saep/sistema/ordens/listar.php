<?php
require_once "../config/auth.php";
verificarSessao();
require_once "../config/conexao.php";

// Ordenado pela data de abertura (mais recentes primeiro) + dados do cliente e equipamento
$result = $conn->query("
    SELECT os.*,
           c.nome AS cliente_nome,
           c.telefone AS cliente_telefone,
           e.tipo AS equip_tipo,
           e.marca AS equip_marca,
           e.modelo AS equip_modelo,
           u.nome AS tecnico_nome
    FROM ordens_servico os
    INNER JOIN clientes c ON c.id = os.cliente_id
    INNER JOIN equipamentos e ON e.id = os.equipamento_id
    INNER JOIN usuarios u ON u.id = os.usuario_id
    ORDER BY os.data_abertura DESC
");
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Ordens de Serviço - SAEP</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header class="topbar">
        <strong>SAEP Assistência Técnica</strong>
        <div><?= htmlspecialchars($_SESSION["usuario_nome"]) ?> | <a href="../dashboard.php">Principal</a> | <a href="../logout.php">Sair</a></div>
    </header>
    <main class="container">
        <div class="page-title">
            <div>
                <h1>Ordens de Serviço</h1>
                <p>Registros ordenados pela data de abertura.</p>
            </div>
            <a class="button" href="cadastrar.php">Nova OS</a>
        </div>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Data Abertura</th>
                        <th>Cliente</th>
                        <th>Equipamento</th>
                        <th>Problema</th>
                        <th>Status</th>
                        <th>Técnico</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($os = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= $os["id"] ?></td>
                            <td><?= date("d/m/Y H:i", strtotime($os["data_abertura"])) ?></td>
                            <td>
                                <?= htmlspecialchars($os["cliente_nome"]) ?><br>
                                <small><?= htmlspecialchars($os["cliente_telefone"]) ?></small>
                            </td>
                            <td>
                                <?= htmlspecialchars($os["equip_tipo"]) ?> -
                                <?= htmlspecialchars($os["equip_marca"]) ?>
                                <?= htmlspecialchars($os["equip_modelo"]) ?>
                            </td>
                            <td><?= htmlspecialchars(mb_strimwidth($os["descricao_problema"], 0, 50, "...")) ?></td>
                            <td><?= htmlspecialchars($os["status"]) ?></td>
                            <td><?= htmlspecialchars($os["tecnico_nome"]) ?></td>
                            <td>
                                <a href="editar.php?id=<?= $os["id"] ?>">Editar</a> |
                                <a href="excluir.php?id=<?= $os["id"] ?>" onclick="return confirm('Deseja realmente excluir esta ordem de serviço?')">Excluir</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>
