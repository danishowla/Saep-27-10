<?php
session_start();
require_once "config/conexao.php";

$erro = "";
if (isset($_GET["expirado"])) {
    $erro = "Sua sessão expirou. Faça login novamente.";
}

if (isset($_SESSION["usuario_id"])) {
    header("Location: dashboard.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? "");
    $senha = trim($_POST["senha"] ?? "");

    if ($email === "" || $senha === "") {
        $erro = "Preencha e-mail e senha.";
    } else {
        $stmt = $conn->prepare("SELECT id, nome, email, senha, perfil FROM usuarios WHERE email = ? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows === 1) {
            $u = $resultado->fetch_assoc();
            if (password_verify($senha, $u["senha"])) {
                $_SESSION["usuario_id"] = $u["id"];
                $_SESSION["usuario_nome"] = $u["nome"];
                $_SESSION["usuario_perfil"] = $u["perfil"];
                $_SESSION["ultimo_acesso"] = time();
                header("Location: dashboard.php");
                exit;
            }
        }
        $erro = "E-mail ou senha inválidos.";
    }
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SAEP - Login</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="login-page">
    <div class="login-card">
        <h1>SAEP Assistência</h1>
        <p>Gestão de Clientes, Equipamentos e Ordens de Serviço</p>
        <?php if ($erro): ?>
            <div class="alert error"><?= htmlspecialchars($erro) ?></div>
        <?php endif; ?>
        <form method="post">
            <label>E-mail</label>
            <input type="email" name="email" required autocomplete="username">
            <label>Senha</label>
            <input type="password" name="senha" required autocomplete="current-password">
            <button type="submit" class="button-login">Entrar</button>
        </form>
    </div>
</body>
</html>
