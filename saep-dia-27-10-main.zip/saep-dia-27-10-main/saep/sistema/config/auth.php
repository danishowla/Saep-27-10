<?php
/**
 * Controle de autenticação e expiração de sessão (30 minutos)
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$TEMPO_EXPIRACAO = 1800; // 30 minutos em segundos

function verificarSessao() {
    global $TEMPO_EXPIRACAO;

    if (!isset($_SESSION["usuario_id"])) {
        header("Location: " . caminhoLogin());
        exit;
    }

    if (isset($_SESSION["ultimo_acesso"])) {
        if (time() - $_SESSION["ultimo_acesso"] > $TEMPO_EXPIRACAO) {
            session_unset();
            session_destroy();
            header("Location: " . caminhoLogin() . "?expirado=1");
            exit;
        }
    }

    $_SESSION["ultimo_acesso"] = time();
}

function caminhoLogin() {
    // Detecta se está em subpasta (clientes, equipamentos, ordens)
    $script = $_SERVER["SCRIPT_NAME"] ?? "";
    if (strpos($script, "/clientes/") !== false ||
        strpos($script, "/equipamentos/") !== false ||
        strpos($script, "/ordens/") !== false) {
        return "../login.php";
    }
    return "login.php";
}

function caminhoBase() {
    $script = $_SERVER["SCRIPT_NAME"] ?? "";
    if (strpos($script, "/clientes/") !== false ||
        strpos($script, "/equipamentos/") !== false ||
        strpos($script, "/ordens/") !== false) {
        return "../";
    }
    return "";
}
