<?php
require_once "../config/auth.php";
verificarSessao();
require_once "../config/conexao.php";

$result = $conn->query("
    SELECT e.*, c.nome AS cliente_nome
    FROM equipamentos e
    INNER JOIN clientes c ON c.id = e.cliente_id
    ORDER BY e.id DESC
");
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Equipamentos - SAEP</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header class="topbar">
        <strong>SAEP Assistência Técnica</strong>
        <div><?= htmlspecialchars($_SESSION["usuario_nome"]) ?> | <a href="../dashboard.php">Principal</a> | <a href="../logout.php">Sair</a></div>
    </header>
    <main class="container">
        <div class="page-title">
            <div>
                <h1>Equipamentos</h1>
                <p>Gerenciamento de equipamentos associados a clientes.</p>
            </div>
            <a class="button" href="cadastrar.php">Novo equipamento</a>
        </div>
        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Cliente</th>
                        <th>Tipo</th>
                        <th>Marca</th>
                        <th>Modelo</th>
                        <th>Nº Série</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($eq = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= $eq["id"] ?></td>
                            <td><?= htmlspecialchars($eq["cliente_nome"]) ?></td>
                            <td><?= htmlspecialchars($eq["tipo"]) ?></td>
                            <td><?= htmlspecialchars($eq["marca"]) ?></td>
                            <td><?= htmlspecialchars($eq["modelo"]) ?></td>
                            <td><?= htmlspecialchars($eq["numero_serie"] ?? "") ?></td>
                            <td>
                                <a href="editar.php?id=<?= $eq["id"] ?>">Editar</a> |
                                <a href="excluir.php?id=<?= $eq["id"] ?>" onclick="return confirm('Deseja realmente excluir este equipamento?')">Excluir</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>
