<?php
require_once "../config/auth.php";
verificarSessao();
require_once "../config/conexao.php";

$clientes = $conn->query("SELECT id, nome FROM clientes ORDER BY nome");
$erro = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $cliente_id = intval($_POST["cliente_id"] ?? 0);
    $tipo = trim($_POST["tipo"] ?? "");
    $marca = trim($_POST["marca"] ?? "");
    $modelo = trim($_POST["modelo"] ?? "");
    $numero_serie = trim($_POST["numero_serie"] ?? "");
    $descricao = trim($_POST["descricao"] ?? "");

    if ($cliente_id <= 0 || $tipo === "" || $marca === "" || $modelo === "") {
        $erro = "Cliente, tipo, marca e modelo são obrigatórios.";
    } else {
        $stmt = $conn->prepare("INSERT INTO equipamentos (cliente_id, tipo, marca, modelo, numero_serie, descricao) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("isssss", $cliente_id, $tipo, $marca, $modelo, $numero_serie, $descricao);
        if ($stmt->execute()) {
            header("Location: listar.php");
            exit;
        }
        $erro = "Erro ao cadastrar equipamento.";
    }
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <title>Novo Equipamento - SAEP</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header class="topbar">
        <strong>SAEP Assistência Técnica</strong>
        <div><?= htmlspecialchars($_SESSION["usuario_nome"]) ?> | <a href="../logout.php">Sair</a></div>
    </header>
    <main class="container form-container">
        <h1>Novo Equipamento</h1>
        <?php if ($erro): ?><div class="alert error"><?= htmlspecialchars($erro) ?></div><?php endif; ?>
        <form method="post">
            <label>Cliente *</label>
            <select name="cliente_id" required>
                <option value="">Selecione o cliente</option>
                <?php while ($c = $clientes->fetch_assoc()): ?>
                    <option value="<?= $c["id"] ?>" <?= (isset($_POST["cliente_id"]) && $_POST["cliente_id"] == $c["id"]) ? "selected" : "" ?>>
                        <?= htmlspecialchars($c["nome"]) ?>
                    </option>
                <?php endwhile; ?>
            </select>
            <label>Tipo *</label>
            <input name="tipo" required placeholder="Notebook, Desktop, Impressora..." value="<?= htmlspecialchars($_POST["tipo"] ?? "") ?>">
            <label>Marca *</label>
            <input name="marca" required value="<?= htmlspecialchars($_POST["marca"] ?? "") ?>">
            <label>Modelo *</label>
            <input name="modelo" required value="<?= htmlspecialchars($_POST["modelo"] ?? "") ?>">
            <label>Número de Série</label>
            <input name="numero_serie" value="<?= htmlspecialchars($_POST["numero_serie"] ?? "") ?>">
            <label>Descrição</label>
            <textarea name="descricao" rows="3"><?= htmlspecialchars($_POST["descricao"] ?? "") ?></textarea>
            <button type="submit">Salvar</button>
            <a class="button secondary" href="listar.php">Cancelar</a>
        </form>
    </main>
</body>
</html>
