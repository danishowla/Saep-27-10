<?php
require_once "../config/auth.php";
verificarSessao();
require_once "../config/conexao.php";

$id = intval($_GET["id"] ?? 0);
$stmt = $conn->prepare("SELECT * FROM equipamentos WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$eq = $stmt->get_result()->fetch_assoc();

if (!$eq) {
    die("Equipamento não encontrado.");
}

$clientes = $conn->query("SELECT id, nome FROM clientes ORDER BY nome");
$erro = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $cliente_id = intval($_POST["cliente_id"] ?? 0);
    $tipo = trim($_POST["tipo"] ?? "");
    $marca = trim($_POST["marca"] ?? "");
    $modelo = trim($_POST["modelo"] ?? "");
    $numero_serie = trim($_POST["numero_serie"] ?? "");
    $descricao = trim($_POST["descricao"] ?? "");

    if ($cliente_id <= 0 || $tipo === "" || $marca === "" || $modelo === "") {
        $erro = "Cliente, tipo, marca e modelo são obrigatórios.";
    } else {
        $stmt = $conn->prepare("UPDATE equipamentos SET cliente_id=?, tipo=?, marca=?, modelo=?, numero_serie=?, descricao=? WHERE id=?");
        $stmt->bind_param("isssssi", $cliente_id, $tipo, $marca, $modelo, $numero_serie, $descricao, $id);
        if ($stmt->execute()) {
            header("Location: listar.php");
            exit;
        }
        $erro = "Erro ao atualizar equipamento.";
    }
} else {
    $_POST = $eq;
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <title>Editar Equipamento - SAEP</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header class="topbar">
        <strong>SAEP Assistência Técnica</strong>
        <div><?= htmlspecialchars($_SESSION["usuario_nome"]) ?> | <a href="../logout.php">Sair</a></div>
    </header>
    <main class="container form-container">
        <h1>Editar Equipamento</h1>
        <?php if ($erro): ?><div class="alert error"><?= htmlspecialchars($erro) ?></div><?php endif; ?>
        <form method="post">
            <label>Cliente *</label>
            <select name="cliente_id" required>
                <?php
                $clientes->data_seek(0);
                while ($c = $clientes->fetch_assoc()):
                ?>
                    <option value="<?= $c["id"] ?>" <?= (($_POST["cliente_id"] ?? $eq["cliente_id"]) == $c["id"]) ? "selected" : "" ?>>
                        <?= htmlspecialchars($c["nome"]) ?>
                    </option>
                <?php endwhile; ?>
            </select>
            <label>Tipo *</label>
            <input name="tipo" required value="<?= htmlspecialchars($_POST["tipo"] ?? "") ?>">
            <label>Marca *</label>
            <input name="marca" required value="<?= htmlspecialchars($_POST["marca"] ?? "") ?>">
            <label>Modelo *</label>
            <input name="modelo" required value="<?= htmlspecialchars($_POST["modelo"] ?? "") ?>">
            <label>Número de Série</label>
            <input name="numero_serie" value="<?= htmlspecialchars($_POST["numero_serie"] ?? "") ?>">
            <label>Descrição</label>
            <textarea name="descricao" rows="3"><?= htmlspecialchars($_POST["descricao"] ?? "") ?></textarea>
            <button type="submit">Salvar</button>
            <a class="button secondary" href="listar.php">Cancelar</a>
        </form>
    </main>
</body>
</html>
