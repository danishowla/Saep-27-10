<?php
require_once "../config/auth.php";
verificarSessao();
require_once "../config/conexao.php";

$id = intval($_GET["id"] ?? 0);
if ($id > 0) {
    $stmt = $conn->prepare("DELETE FROM equipamentos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}
header("Location: listar.php");
exit;
