<?php
require_once "config/auth.php";
verificarSessao();
require_once "config/conexao.php";

$totalClientes = $totalEquip = $totalOS = $osAbertas = 0;

$r = $conn->query("SELECT COUNT(*) AS t FROM clientes");
if ($r) $totalClientes = (int)$r->fetch_assoc()["t"];

$r = $conn->query("SELECT COUNT(*) AS t FROM equipamentos");
if ($r) $totalEquip = (int)$r->fetch_assoc()["t"];

$r = $conn->query("SELECT COUNT(*) AS t FROM ordens_servico");
if ($r) $totalOS = (int)$r->fetch_assoc()["t"];

$r = $conn->query("SELECT COUNT(*) AS t FROM ordens_servico WHERE status = 'Aberta'");
if ($r) $osAbertas = (int)$r->fetch_assoc()["t"];
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>SAEP - Principal</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header class="topbar">
        <strong>SAEP Assistência Técnica</strong>
        <div><?= htmlspecialchars($_SESSION["usuario_nome"]) ?> | <a href="logout.php">Sair</a></div>
    </header>
    <main class="container">
        <h1>Área Principal</h1>
        <p>Bem-vindo(a), <strong><?= htmlspecialchars($_SESSION["usuario_nome"]) ?></strong>. Utilize o menu abaixo para gerenciar o sistema.</p>
        <div class="cards">
            <div class="card"><span>Clientes</span><strong><?= $totalClientes ?></strong></div>
            <div class="card"><span>Equipamentos</span><strong><?= $totalEquip ?></strong></div>
            <div class="card"><span>Ordens de Serviço</span><strong><?= $totalOS ?></strong></div>
            <div class="card"><span>OS Abertas</span><strong><?= $osAbertas ?></strong></div>
        </div>
        <div class="actions">
            <a class="button" href="clientes/listar.php">Gerenciar Clientes</a>
            <a class="button" href="equipamentos/listar.php">Gerenciar Equipamentos</a>
            <a class="button" href="ordens/listar.php">Gerenciar Ordens de Serviço</a>
            <a class="button secondary" href="logout.php">Sair do sistema</a>
        </div>
    </main>
</body>
</html>
