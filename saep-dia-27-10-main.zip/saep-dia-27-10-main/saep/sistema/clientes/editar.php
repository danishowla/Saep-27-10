<?php
require_once "../config/auth.php";
verificarSessao();
require_once "../config/conexao.php";

$id = intval($_GET["id"] ?? 0);
$stmt = $conn->prepare("SELECT * FROM clientes WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$cliente = $stmt->get_result()->fetch_assoc();

if (!$cliente) {
    die("Cliente não encontrado.");
}

$erro = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome = trim($_POST["nome"] ?? "");
    $cpf = trim($_POST["cpf"] ?? "");
    $telefone = trim($_POST["telefone"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $endereco = trim($_POST["endereco"] ?? "");

    if ($nome === "" || $cpf === "" || $telefone === "") {
        $erro = "Nome, CPF e telefone são obrigatórios.";
    } else {
        $stmt = $conn->prepare("UPDATE clientes SET nome=?, cpf=?, telefone=?, email=?, endereco=? WHERE id=?");
        $stmt->bind_param("sssssi", $nome, $cpf, $telefone, $email, $endereco, $id);
        if ($stmt->execute()) {
            header("Location: listar.php");
            exit;
        }
        $erro = "Erro ao atualizar. Verifique se o CPF já existe.";
    }
} else {
    $_POST = $cliente;
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <title>Editar Cliente - SAEP</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header class="topbar">
        <strong>SAEP Assistência Técnica</strong>
        <div><?= htmlspecialchars($_SESSION["usuario_nome"]) ?> | <a href="../logout.php">Sair</a></div>
    </header>
    <main class="container form-container">
        <h1>Editar Cliente</h1>
        <?php if ($erro): ?><div class="alert error"><?= htmlspecialchars($erro) ?></div><?php endif; ?>
        <form method="post">
            <label>Nome *</label>
            <input name="nome" required value="<?= htmlspecialchars($_POST["nome"] ?? "") ?>">
            <label>CPF *</label>
            <input name="cpf" required value="<?= htmlspecialchars($_POST["cpf"] ?? "") ?>">
            <label>Telefone *</label>
            <input name="telefone" required value="<?= htmlspecialchars($_POST["telefone"] ?? "") ?>">
            <label>E-mail</label>
            <input type="email" name="email" value="<?= htmlspecialchars($_POST["email"] ?? "") ?>">
            <label>Endereço</label>
            <input name="endereco" value="<?= htmlspecialchars($_POST["endereco"] ?? "") ?>">
            <button type="submit">Salvar</button>
            <a class="button secondary" href="listar.php">Cancelar</a>
        </form>
    </main>
</body>
</html>
