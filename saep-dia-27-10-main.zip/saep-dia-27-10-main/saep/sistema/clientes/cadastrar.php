<?php
require_once "../config/auth.php";
verificarSessao();
require_once "../config/conexao.php";

$erro = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome = trim($_POST["nome"] ?? "");
    $cpf = trim($_POST["cpf"] ?? "");
    $telefone = trim($_POST["telefone"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $endereco = trim($_POST["endereco"] ?? "");

    if ($nome === "" || $cpf === "" || $telefone === "") {
        $erro = "Nome, CPF e telefone são obrigatórios.";
    } else {
        $stmt = $conn->prepare("INSERT INTO clientes (nome, cpf, telefone, email, endereco) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $nome, $cpf, $telefone, $email, $endereco);
        if ($stmt->execute()) {
            header("Location: listar.php");
            exit;
        }
        $erro = "Erro ao cadastrar. Verifique se o CPF já existe.";
    }
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <title>Novo Cliente - SAEP</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header class="topbar">
        <strong>SAEP Assistência Técnica</strong>
        <div><?= htmlspecialchars($_SESSION["usuario_nome"]) ?> | <a href="../logout.php">Sair</a></div>
    </header>
    <main class="container form-container">
        <h1>Novo Cliente</h1>
        <?php if ($erro): ?><div class="alert error"><?= htmlspecialchars($erro) ?></div><?php endif; ?>
        <form method="post">
            <label>Nome *</label>
            <input name="nome" required value="<?= htmlspecialchars($_POST["nome"] ?? "") ?>">
            <label>CPF *</label>
            <input name="cpf" required placeholder="000.000.000-00" value="<?= htmlspecialchars($_POST["cpf"] ?? "") ?>">
            <label>Telefone *</label>
            <input name="telefone" required value="<?= htmlspecialchars($_POST["telefone"] ?? "") ?>">
            <label>E-mail</label>
            <input type="email" name="email" value="<?= htmlspecialchars($_POST["email"] ?? "") ?>">
            <label>Endereço</label>
            <input name="endereco" value="<?= htmlspecialchars($_POST["endereco"] ?? "") ?>">
            <button type="submit">Salvar</button>
            <a class="button secondary" href="listar.php">Cancelar</a>
        </form>
    </main>
</body>
</html>
