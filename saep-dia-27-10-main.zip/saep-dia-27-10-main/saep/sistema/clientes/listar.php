<?php
require_once "../config/auth.php";
verificarSessao();
require_once "../config/conexao.php";

$termo = trim($_GET["busca"] ?? "");
$clientes = [];

if ($termo !== "") {
    $like = "%" . $termo . "%";
    $stmt = $conn->prepare("SELECT * FROM clientes WHERE nome LIKE ? OR cpf LIKE ? OR telefone LIKE ? OR email LIKE ? ORDER BY nome");
    $stmt->bind_param("ssss", $like, $like, $like, $like);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM clientes ORDER BY nome");
}

while ($row = $result->fetch_assoc()) {
    $clientes[] = $row;
}
?>
<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Clientes - SAEP</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header class="topbar">
        <strong>SAEP Assistência Técnica</strong>
        <div><?= htmlspecialchars($_SESSION["usuario_nome"]) ?> | <a href="../dashboard.php">Principal</a> | <a href="../logout.php">Sair</a></div>
    </header>
    <main class="container">
        <div class="page-title">
            <div>
                <h1>Clientes</h1>
                <p>Cadastro e busca de clientes.</p>
            </div>
            <a class="button" href="cadastrar.php">Novo cliente</a>
        </div>

        <form method="get" style="margin: 20px 0; display: flex; gap: 10px; align-items: flex-end;">
            <div style="flex:1">
                <label>Buscar cliente</label>
                <input type="text" name="busca" value="<?= htmlspecialchars($termo) ?>" placeholder="Nome, CPF, telefone ou e-mail">
            </div>
            <button type="submit">Buscar</button>
            <?php if ($termo !== ""): ?>
                <a class="button secondary" href="listar.php">Limpar</a>
            <?php endif; ?>
        </form>

        <div class="table-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>CPF</th>
                        <th>Telefone</th>
                        <th>E-mail</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($clientes)): ?>
                        <tr><td colspan="6">Nenhum cliente encontrado.</td></tr>
                    <?php else: ?>
                        <?php foreach ($clientes as $c): ?>
                            <tr>
                                <td><?= $c["id"] ?></td>
                                <td><?= htmlspecialchars($c["nome"]) ?></td>
                                <td><?= htmlspecialchars($c["cpf"]) ?></td>
                                <td><?= htmlspecialchars($c["telefone"]) ?></td>
                                <td><?= htmlspecialchars($c["email"] ?? "") ?></td>
                                <td>
                                    <a href="editar.php?id=<?= $c["id"] ?>">Editar</a> |
                                    <a href="excluir.php?id=<?= $c["id"] ?>" onclick="return confirm('Deseja realmente excluir este cliente?')">Excluir</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>
